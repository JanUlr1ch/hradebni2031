﻿
namespace SeminárkaV2
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Lane1 = new System.Windows.Forms.PictureBox();
            this.Lane2 = new System.Windows.Forms.PictureBox();
            this.Lane3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.Lane4 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.car1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Lane1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Lane2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Lane3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Lane4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.car1)).BeginInit();
            this.SuspendLayout();
            // 
            // Lane1
            // 
            this.Lane1.BackColor = System.Drawing.Color.White;
            this.Lane1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Lane1.Location = new System.Drawing.Point(184, -76);
            this.Lane1.Name = "Lane1";
            this.Lane1.Size = new System.Drawing.Size(16, 108);
            this.Lane1.TabIndex = 0;
            this.Lane1.TabStop = false;
            // 
            // Lane2
            // 
            this.Lane2.BackColor = System.Drawing.Color.White;
            this.Lane2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Lane2.Location = new System.Drawing.Point(184, 74);
            this.Lane2.Name = "Lane2";
            this.Lane2.Size = new System.Drawing.Size(16, 108);
            this.Lane2.TabIndex = 1;
            this.Lane2.TabStop = false;
            // 
            // Lane3
            // 
            this.Lane3.BackColor = System.Drawing.Color.White;
            this.Lane3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Lane3.Location = new System.Drawing.Point(184, 243);
            this.Lane3.Name = "Lane3";
            this.Lane3.Size = new System.Drawing.Size(16, 108);
            this.Lane3.TabIndex = 2;
            this.Lane3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.LightGray;
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox4.Location = new System.Drawing.Point(-5, -13);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(34, 490);
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.LightGray;
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox5.Location = new System.Drawing.Point(354, -13);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(36, 490);
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.White;
            this.pictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox6.Location = new System.Drawing.Point(23, -13);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(18, 490);
            this.pictureBox6.TabIndex = 5;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.White;
            this.pictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox7.Location = new System.Drawing.Point(345, -13);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(18, 490);
            this.pictureBox7.TabIndex = 6;
            this.pictureBox7.TabStop = false;
            // 
            // Lane4
            // 
            this.Lane4.BackColor = System.Drawing.Color.White;
            this.Lane4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Lane4.Location = new System.Drawing.Point(184, 416);
            this.Lane4.Name = "Lane4";
            this.Lane4.Size = new System.Drawing.Size(16, 108);
            this.Lane4.TabIndex = 7;
            this.Lane4.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // car1
            // 
            this.car1.Image = ((System.Drawing.Image)(resources.GetObject("car1.Image")));
            this.car1.Location = new System.Drawing.Point(61, 349);
            this.car1.Name = "car1";
            this.car1.Size = new System.Drawing.Size(70, 100);
            this.car1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.car1.TabIndex = 8;
            this.car1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(384, 461);
            this.Controls.Add(this.car1);
            this.Controls.Add(this.Lane4);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.Lane3);
            this.Controls.Add(this.Lane2);
            this.Controls.Add(this.Lane1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.Lane1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Lane2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Lane3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Lane4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.car1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox Lane1;
        private System.Windows.Forms.PictureBox Lane2;
        private System.Windows.Forms.PictureBox Lane3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox Lane4;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox car1;
    }
}

