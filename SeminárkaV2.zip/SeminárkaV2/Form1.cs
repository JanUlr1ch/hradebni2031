﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeminárkaV2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //public class Exceptions
        //{
        //    static int Delitel(int a, int b)
        //    {
                
        //    }
            
        //}
        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        int a = 10;   
        private void timer1_Tick(object sender, EventArgs e)
        {
            moveline(a/2);
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
            {
                if (a < 500) //pozn. změnit podle typu/vylepšení auta
                { a++; }
                if(car1.Top >= 0)
                { car1.Top += -1; }
            }
            if(e.KeyCode ==Keys.Down)
            {
                if (car1.Top <= 500)
                { car1.Top += 1; }
                if(a > 0)
                { a--; }
            }
            int c = 0;
            if(c == 5)
            {
                c += 5;
            }
            else
            {
                c = a / 5;
            }
            
            //podmínky slouží k pohybu modelu po dráze (pozn. přidat pause/menu znak)
            
            if (e.KeyCode == Keys.Left)
            {
                if (car1.Left >= 45)
                { car1.Left += -5; }
            }
            if (e.KeyCode == Keys.Right)
            {
                if (car1.Right <= 340)
                { car1.Left += 5; }
            }
        }

        void moveline(int a)
        {
            //podmínky slouží pro opakovaný pohyb čar silnice
            if (Lane1.Top>=500)
            { Lane1.Top = -100; }
            else
            { Lane1.Top += a; }

            if (Lane2.Top >= 500)
            { Lane2.Top = -100; }
            else
            { Lane2.Top += a; }

            if (Lane3.Top >= 500)
            { Lane3.Top = -100; }
            else
            { Lane3.Top += a; }

            if (Lane4.Top >= 500)
            { Lane4.Top = -100; }
            else
            { Lane4.Top += a; }
        }
        
       

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
        //    if (e.KeyChar == Keys.Escape)
        //    {

        //    }
        }

        
    }
}
